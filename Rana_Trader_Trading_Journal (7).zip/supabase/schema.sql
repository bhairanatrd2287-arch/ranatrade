-- Run this in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  starting_capital numeric(14,2) not null default 10000,
  currency text not null default 'USD',
  created_at timestamptz not null default now()
);

create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  symbol text not null,
  side text not null check (side in ('BUY','SELL')),
  entry_price numeric(20,8) not null,
  exit_price numeric(20,8),
  stop_loss numeric(20,8),
  target_price numeric(20,8),
  quantity numeric(20,8) not null default 1,
  status text not null default 'OPEN' check (status in ('OPEN','CLOSED')),
  pnl numeric(20,2) not null default 0,
  notes text not null default '',
  screenshot_url text,
  traded_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.trades enable row level security;

create policy "Users can read own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);
create policy "Users can create own profile" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
create policy "Users can update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "Users can read own trades" on public.trades
  for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert own trades" on public.trades
  for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update own trades" on public.trades
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete own trades" on public.trades
  for delete to authenticated using (auth.uid() = user_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Important: use the anon/publishable key in the frontend, never the service-role key.
-- RLS policies above isolate profile/trade rows by the authenticated user id.

-- Private screenshot storage. Create a private bucket named `trade-screenshots`
-- in Supabase Storage before using screenshot upload.
insert into storage.buckets (id, name, public)
values ('trade-screenshots', 'trade-screenshots', false)
on conflict (id) do nothing;

create policy "Users upload their own trade screenshots"
on storage.objects for insert to authenticated
with check (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users view their own trade screenshots"
on storage.objects for select to authenticated
using (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users delete their own trade screenshots"
on storage.objects for delete to authenticated
using (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);


-- Optional trade screenshot storage. Create a private bucket.
insert into storage.buckets (id, name, public)
values ('trade-screenshots', 'trade-screenshots', false)
on conflict (id) do nothing;

create policy "Users upload screenshots to own folder"
on storage.objects for insert to authenticated
with check (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Users view screenshots in own folder"
on storage.objects for select to authenticated
using (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Users delete screenshots in own folder"
on storage.objects for delete to authenticated
using (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text);
