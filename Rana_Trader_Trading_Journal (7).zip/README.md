# Rana Trader — Trading Journal Dashboard

Responsive React/Vite starter for a personal trading journal.

## Included
- Dark responsive dashboard, mobile navigation and summary cards
- Google OAuth sign-in using Supabase Auth
- Supabase cloud persistence for starting capital and trades
- Row Level Security policies to isolate each user's data
- Journal create/close/delete flow, P&L calculations and per-trade screenshot upload
- Market chart panel built with TradingView Lightweight Charts
- Demo mode when Supabase credentials are not configured

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and fill in your Supabase Project URL and anon/publishable key.
3. Run `npm install` and `npm run dev`.

Without Supabase settings, the app opens in clearly labeled demo mode using browser local storage. Demo mode is not secure cloud storage and does not sync devices.

## Configure Google sign-in + cloud sync
1. Create a Supabase project.
2. Run `supabase/schema.sql` in its SQL Editor.
3. In Supabase Authentication > Providers, enable Google and add your Google OAuth client ID/secret.
4. In Google Cloud Console, configure the OAuth consent screen and add the Supabase callback URL shown in Supabase's Google provider settings as an authorized redirect URI.
5. In Supabase Storage, confirm the private `trade-screenshots` bucket and policies created by `supabase/schema.sql`.
6. Add your website origin and production URL in Supabase Authentication URL Configuration, including the local dev URL (for example `http://localhost:5173`).
7. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to `.env`, restart Vite.

## Market data
The chart uses seeded illustrative candles so the UI works immediately. They are NOT live quotes. Connect a licensed market data provider to a secure backend/serverless endpoint for live Gold/Forex/BTC prices. Do not expose private provider API keys in browser code. Live prices and trading decisions are not supplied by this starter.

## Production checklist
- Deploy the built app to HTTPS hosting.
- Set production environment variables and OAuth redirect URLs.
- Verify RLS policies and OAuth flow using two separate accounts.
- Add server-side market data provider, monitoring, backups, and provider-specific rate limits.
- Review privacy, terms, and financial-data compliance before public launch.

## Trade screenshots
The trade form accepts an optional image screenshot. Demo mode stores it in browser local storage. In cloud mode it uploads privately to the Supabase `trade-screenshots` bucket, with storage policies restricting each user's folder. Run the updated `supabase/schema.sql` before using cloud screenshot uploads.
